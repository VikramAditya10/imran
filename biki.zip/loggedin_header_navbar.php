<body>
<script>
    
		window.onload=function(){window.jQuery?$(document).ready(function(){$(".sidebarNavigation .navbar-collapse").hide().clone().appendTo("body").removeAttr("class").addClass("sideMenu").show(),$("body").append("<div class='overlay'></div>"),$(".sideMenu").addClass($(".sidebarNavigation").attr("data-sidebarClass")),$(".navbar-toggle, .navbar-toggler").on("click",function(){$(".sideMenu, .overlay").toggleClass("open"),$(".overlay").on("click",function(){$(this).removeClass("open"),$(".sideMenu").removeClass("open")})}),$("body").on("click",".sideMenu.open .nav-item",function(){$(this).hasClass("dropdown")||$(".sideMenu, .overlay").toggleClass("open")}),$(window).resize(function(){$(".navbar-toggler").is(":hidden")?$(".sideMenu, .overlay").hide():$(".sideMenu, .overlay").show()})}):console.log("sidebarNavigation Requires jQuery")};
    </script>

    <style> 
        input[type=search] {
            width: 150px;
            height: 50px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 200px;
            font-size: 16px;
            background-color: white;
            background-image: url('searchicon.png');
            background-repeat: no-repeat;
            background-size: 35px;
            background-position: 12px 12px; 
            background-repeat: no-repeat;
            padding: 15px 20px 15px 40px;
            -webkit-transition: width 0.4s ease-in-out;
            transition: width 0.4s ease-in-out;
        }

        input[type=search]:focus {
            width: 80%;
            z-index: -1;
        }

  body{position:relative}
  .overlay,.sideMenu{position:fixed;bottom:0}
  .overlay{top:0;left:-100%;right:100%;margin:auto;background-color:rgba(0,0,0,.5);z-index:998;transition:all ease 0.2s}
  .overlay.open{left:0;right:0}
  .sidebarNavigation{margin-bottom:0;z-index:999;justify-content:flex-start}
  .sidebarNavigation .leftNavbarToggler{margin-right:10px;order:-1}
  .sideMenu{left:-100%;top:52px;transition:all ease 0.5s;overflow:hidden;width:100%;z-index:999;max-width:80%;margin-bottom:0;padding:1rem}
  .sideMenu.open{left:0;display:block;overflow-y:auto}.sideMenu ul{margin:0;padding:0 15px}
  
 
    </style>
    

  <!--  <div class="custom-fixednav" id="myTopnav1" style="position:relative;z-index:1000;">
        <div class="container" >
		<div class="d-flex">
  <div class="p-10"><input style="margin-top:5%;" type="search" name="search"  placeholder="Search.."></div>
  <div class="ml-auto p-1"><div class="dropdown">
  <button type="button" class="btn" data-toggle="dropdown" style="background-color: transparent;border-color:transparent;box-shadow: none;">
 <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADfSURBVFhH7ZgxCsJAFERT6RnUY6in0ErQwkY9nWCtXiseQKLvwyDomirIjzAPhiz7p3gQNgmpjDE/pmmaIbmS+0PEmlxiploeSCzlVcBsoVoeSGzlUxAz1fKwYFeQmMvnG1PVckHyQI4InSKxJjuNjTEciAlZcUDWkVjHnsa5hAhSN/IG+zUZq5YHEhs5FcRMtTyQ8KuuE3Eb5VMQM9XyQCJOcC2nF7FHRqrlIsnPx0w/5IzpAxyI4oOV617jXJBp/eRnNlMtDyT8quvEPwj2/tdH28+jM8uBasaY31BVT0SjcttnrqNxAAAAAElFTkSuQmCC">
  </button>
  <div class="dropdown-menu" style="background-color:rgb(232, 212, 247);color:black;">
    <a  class="dropdown-item" href="upload_photo.php"><i class="fa fa-upload" aria-hidden="true"></i> Upload</a>
    <a  class="dropdown-item" href="index.php"><i class="fa fa-sign-out" aria-hidden="true"></i> Sign Out</a>
	 <a class="dropdown-item" href="user_profile.php"><i class="fa fa-user-circle" aria-hidden="true"></i> Profile</a>
  </div>
</div></div>
</div>
        </div>
    </div>


    <div class="custom-header">

      <div class="d-flex justify-content-center">  <a href="#default" class="logo"><h1 style="color:white;z-index: 10;"><i><b>Asterixis</b></i></h1></a></div>



    </div>

    <div class="custom-topnav" id="myTopnav">
        <a href="index.php" >Home</a>

        <div class="drop">
            <button class="dropbtn">College Week 
                <i class="fa fa-caret-down"></i>
            </button>
            <div class="drop-content">
                <a href="#">2017</a>
                <a href="collegeweek.php">2018</a>

            </div>
        </div>
        <div class="drop">
            <button class="dropbtn">Medifest
                <i class="fa fa-caret-down"></i>
            </button>
            <div class="drop-content">
                <a href="#">2017</a>
                <a href="">2018</a>

            </div>
        </div>
        <div class="drop">
            <button class="dropbtn">Articles
                <i class="fa fa-caret-down"></i>
            </button>
            <div class="drop-content">
                <a href="poem.php">Poems</a>
                <a href="">Stories</a>

            </div>
        </div>

        <div class="drop">
            <button class="dropbtn">Trending
                <i class="fa fa-caret-down"></i>
            </button>
            <div class="drop-content">
                <a href="#">Recent</a>


            </div>
        </div>
        <a href="gallery.php">Gallery</a>
        <div class="drop">
            <button class="dropbtn">Batches
                <i class="fa fa-caret-down"></i>
            </button>
            <div class="drop-content">
                <a href="troezianz.php">Troezianz</a>
                <a href="#">Other Bathes</a>

            </div>
        </div>
        <a href="">Pink Pallette</a>
        <a href="">Miscellaneous</a>
        <a href="aboutus.php">About us</a>
        <a href="contact.php">Contact</a>

        <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>




    </div>-->
 <nav class="navbar navbar-expand-md navbar-dark bg-dark sidebarNavigation" data-sidebarClass="navbar-dark bg-dark">
        <a class="navbar-brand" href="http://asterixis.in/">Asterixis</a>
        <button class="navbar-toggler leftNavbarToggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault"
            aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="http://asterixis.in/">Home
                        <span class="sr-only">(current)</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="modal" data-target="#userLoginModal1" href="#">SignIn</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="articles" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Articles</a>
<div class="dropdown-menu" aria-labelledby="articles">
                       <a class="dropdown-item" href="poem.php">Poems</a>
						<a class="dropdown-item" href="">Stories</a>
                   
                    </div>               
			   </li>
               <li class="nav-item">
                    <a class="nav-link" href="troezianz.php">Troezianz</a>
                </li>
				  <li class="nav-item">
                    <a class="nav-link" href="upload_photo.php"><i class="fa fa-upload" aria-hidden="true"></i> Upload</a></li>
					  <li class="nav-item">
                    <a class="nav-link" href="index.php"><i class="fa fa-sign-out" aria-hidden="true"></i> Sign Out</a></li>
					<li class="nav-item">
                    <a class="nav-link" href="user_profile.php"><i class="fa fa-user-circle" aria-hidden="true"></i> Profile</a></li>
            <form class="form-inline my-2 my-lg-0">
                <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                <!--<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>-->
            </form>
        </div>
    </nav>

    </div>
    <script>
    
		window.onload=function(){window.jQuery?$(document).ready(function(){$(".sidebarNavigation .navbar-collapse").hide().clone().appendTo("body").removeAttr("class").addClass("sideMenu").show(),$("body").append("<div class='overlay'></div>"),$(".sideMenu").addClass($(".sidebarNavigation").attr("data-sidebarClass")),$(".navbar-toggle, .navbar-toggler").on("click",function(){$(".sideMenu, .overlay").toggleClass("open"),$(".overlay").on("click",function(){$(this).removeClass("open"),$(".sideMenu").removeClass("open")})}),$("body").on("click",".sideMenu.open .nav-item",function(){$(this).hasClass("dropdown")||$(".sideMenu, .overlay").toggleClass("open")}),$(window).resize(function(){$(".navbar-toggler").is(":hidden")?$(".sideMenu, .overlay").hide():$(".sideMenu, .overlay").show()})}):console.log("sidebarNavigation Requires jQuery")};
    </script>

    <!---------Navbar End--------------->