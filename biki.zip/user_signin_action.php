<?php
session_start();
include('db.php');

if(isset($_POST)){
	$email=$_POST['uname'];
$pwd=$_POST['pswd'];
$db =new DB();
$result=$db->execute_query("select * from user where email='".$email."' and pswd=PASSWORD('".$pwd."')");
	if($db->num_rows($result)==0){
		$error=array('error'=>true);
	}
	else
		
	{
	$row=$db->fetch_result($result);
$_SESSION['userimage']=$row['image'];
	$_SESSION['username']=$row['name'];
	$error=array('error'=>'index.php');
	}
	$_SESSION['loggedin']=true;
	$_SESSION['email']=$email;
	
	$db->close();
}
//header("Location: http://localhost/imran/demo.html");
echo json_encode($error);
?>
