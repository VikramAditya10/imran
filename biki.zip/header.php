<!DOCTYPE html>
<html>
    <head>
        <title>asterixis</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="title" content="Is a photo sharing website">
<meta name="description" content="Guwahati gauhati gmch medical JDA SSUHS Medical College ">
   


<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
  
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

	 <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
	     <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>

        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
<link rel="stylesheet" href="lib/owlcarousel/owl.carousel.css">
<link rel="stylesheet" href="lib/owlcarousel/owl.theme.default.css">
	<script src="lib/owlcarousel/owl.carousel.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 

 <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
        <script src="https://code.getmdl.io/1.3.0/material.min.js"></script>

<script rel="stylesheet" src="mdl-selectfield.min.js"></script>
        <link rel="stylesheet" href="mdl-selectfield.min.css">
   
      <link rel="stylesheet" type="text/css" href="css/user/main.css">
    
       

        <!-------------------------------------->
        <style>
            .btn:focus, .btn:active, button:focus, button:active {
                outline: none !important;
                box-shadow: none !important;
            }

            #image-gallery .modal-footer{
                display: block;
            }

            .thumb{
                margin-top: 15px;
                margin-bottom: 15px;
            }
        </style>
        <!-------------------------------------->
        <!-------------------------------------------------->
        <style>
            

            #myImg {
                border-radius: 5px;
                cursor: pointer;
                transition: 0.3s;
            }

            #myImg:hover {opacity: 0.7;}

            /* The Modal (background) */
            .modal {
                /* Enable scroll if needed */
                background-color: rgb(0,0,0); /* Fallback color */
                background-color: rgba(0,0,0,0.9); /* Black w/ opacity */
            }

            /* Modal Content (image) */
            .modal-content {
                margin: auto;
                
                width: 75%;
                max-width: 700px;
            }

            /* Caption of Modal Image */
            #caption {
                margin: auto;
                display: block;
                width: 80%;
                max-width: 700px;
                text-align: center;
                color: #ccc;
                padding: 10px 0;
                height: 150px;
            }

            /* Add Animation */
           

            @-webkit-keyframes zoom {
                from {-webkit-transform:scale(0)} 
                to {-webkit-transform:scale(1)}
            }

            @keyframes zoom {
                from {transform:scale(0)} 
                to {transform:scale(1)}
            }

          

            /* 100% Image Width on Smaller Screens */
            @media only screen and (max-width: 700px){
                .modal-content {
                    width: 100%;
                }
            }
        </style>
        <style>


.text-block {
    position: absolute;
    bottom: 20px;
    right: 50px;
    left: 50px;
    background-color:#585858;
    color: white;
   
}
</style>

<style>
    .input-group.md-form.form-sm.form-1 input{
    border: 1px solid #bdbdbd;
    border-top-right-radius: 0.25rem;
    border-bottom-right-radius: 0.25rem;
}
#userLoginModal1{
	color:black;
}
</style>





    </head>