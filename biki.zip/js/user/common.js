$("#usignin").click(function(e){
	var uname=$("#usigninemail").val();
	var pswd=$("#usigninpwd").val();
if(uname.trim()!=''&&pswd!='')
	$.post("user_signin_action.php",{'uname':uname,'pswd':pswd},function(response){
		response=JSON.parse(response);
		if(response.error===true)
	$("#siginError").html("<div class='alert alert-danger alert-dismissible fade show'><button type='button' class='close' data-dismiss='alert'>&times;</button><strong>Error!</strong> Incorrect user id or password</div>");
	else
	location.href = response.error;
	
	});
	else
	$("#siginError").html("<div class='alert alert-danger alert-dismissible fade show'><button type='button' class='close' data-dismiss='alert'>&times;</button><strong>Empty!</strong> Fields cannot be empty</div>");
 e.preventDefault();
	});
	
	$("#btnSignup").click(function(e){
	var uname=$("#usignupuname").val();
	var email=$("#usignupemail").val();
	var pswd=$("#usignuppwd").val();
	var confrmpswd=$("#usignupconfrmpwd").val();

if(uname.trim()!=''&&pswd!=''&&email!=''&&confrmpswd!='')
{

	if(pswd===confrmpswd)
	$.post("user_signup_action.php",{'uname':uname,'email':email,'pswd':pswd},function(response){
		response=JSON.parse(response);
		if(response.error===true)
	$("#sigupError").html("<div class='alert alert-danger alert-dismissible fade show'><button type='button' class='close' data-dismiss='alert'>&times;</button><strong>Error!</strong> Incorrect user id or password</div>");
	else
	location.href = response.error;
	
	});
	else
$("#signupError").html("<div class='alert alert-danger alert-dismissible fade show'><button type='button' class='close' data-dismiss='alert'>&times;</button><strong>Error!</strong>Password doesnot math</div>");		
}
	else 
	$("#signupError").html("<div class='alert alert-danger alert-dismissible fade show'><button type='button' class='close' data-dismiss='alert'>&times;</button><strong>Empty!</strong> Fields cannot be empty</div>");
 //e.preventDefault();
	});
	
	
$(document).ready(function() {
	
    var overlay = $('.sidebar-overlay');
console.log("Side bar");
    $('#sidebarbut').on('click', function() {
		
        var sidebar = $('#sidebar');
        sidebar.toggleClass('open');
        if (sidebar.hasClass('open')) {
            overlay.addClass('active');
        } else {
            overlay.removeClass('active');
        }
    });

    overlay.on('click', function() {
        $(this).removeClass('active');
        $('#sidebar').removeClass('open');
    });

});


(function($) {
    var dropdown = $('.sidebar-dropdown');

    // Add slidedown animation to dropdown
    dropdown.on('show.bs.dropdown', function(e){
        $(this).find('.sidebar-dropdown-menu').first().stop(true, true).slideDown();
    });

    // Add slideup animation to dropdown
    dropdown.on('hide.bs.dropdown', function(e){
        $(this).find('.sidebar-dropdown-menu').first().stop(true, true).slideUp();
    });
})(jQuery);


$(window).scroll(function(){
	if($('#hero_search').length){
		var searchHeight = $("#hero_search").outerHeight();
var offset = $("#hero_search").offset().top;
var totalHeight = searchHeight + offset;
console.log(totalHeight);
    if($(document).scrollTop() >= totalHeight) {
        $('.fixed-search-bar').css({"visibility": "visible"});
    } else {
         $('.fixed-search-bar').css({"visibility": "hidden"});
    }
	}
	
});
$(document).ready(function(){
	if(!$('#hero_search').length){
		 $('.fixed-search-bar').css({"visibility": "visible"});
	}
});

$(document).ready(function() {
$("#home_carousel").owlCarousel({
	loop:true,
    margin:10,
    nav:true,
	items:1,

            nav: true,
           autoplay:true,
		   loop:true,
		   autoplayHoverPause:true,
		   autoplayTimeout:2000
	});
});


$("#signout_link").click(function(e){
$.get("sign_out.php",function(){location.href='index.php';});
 });
 
 function readURL(input) {
        if (input.files && input.files[0]) {

            var reader = new FileReader();
            
            reader.onload = function (e) {
	
                $('#imgPre').attr("src",e.target.result);
            
}
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    
  $("#imgInp").change(function(){
       readURL(this);
    });
	 

$(document).ready(function() {
$("#home_college_week").owlCarousel({
	loop:true,
    margin:10,
    nav:true,
	
	dots:false,
            nav: true,
           autoplay:true,
		   loop:true,
		   autoplayHoverPause:true,
		   autoplayTimeout:2000,
		   responsive:{
        0:{
            items:1,
            nav:true
        },
        600:{
            items:2,
            nav:true
        },
        1000:{
            items:4,
            nav:true,
        }
    }
	});
});

  $('.custom-card-button').click(function(){
                // check paragraph once toggle effect is completed
                if($(this).parent().siblings(".custom-card-caption").is(":visible")){
				
					$(this).parent().siblings(".custom-card-caption").hide();
					$(this).html('Show Caption');
                } else{
              	$(this).parent().siblings(".custom-card-caption").show();
				$(this).html('Hide Caption');
                }
           
	//$('#p').show();
	$('#h').show();
});

