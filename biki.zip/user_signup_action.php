<?php 
include("db.php");
session_start();
$db=new DB();
$uname=$_POST["uname"];
$email=$_POST["email"];
$pwd=$_POST["pswd"];
$sql="insert into user (name, email, pswd, image) values('".$uname."','".$email."',PASSWORD('".$pwd."'),DEFAULT)";

if(!$db->execute_query($sql)){
		$error=array('error'=>true);
	}
	else
		
	{
		$_SESSION['loggedin']=true;
	$sql="select * from user where email='".$email."'";
	$result=$db->execute_query($sql);
		$row=$db->fetch_result($result);
	$_SESSION['email']=$email;
$_SESSION['userimage']=$row['image'];
	$_SESSION['username']=$row['name'];
	$error=array('error'=>'index.php');
	}

	
	$db->close();
echo $error;
	?>