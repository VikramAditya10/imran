<?php include 'header.php'; ?>
<?php include 'header_navbar.php'; ?>

<style>
    

    * {
        box-sizing: border-box;
    }

    .row > .column {
        padding: 0 8px;
    }

    .row:after {
        content: "";
        display: table;
        clear: both;
    }

    .column {
        float: left;
        width: 25%;
    }


    /* The Modal (background) */
    .modal {
        display: none;
        position: fixed;
        z-index: 1;
        padding-top: 100px;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: black;
    }

    /* Modal Content */
    .modal-content {
        position: relative;
        background-color: #fefefe;
        margin: auto;
        padding: 0;
        width: 90%;
        max-height:500px;
        max-width: 1500px;
    }

    /* The Close Button */
    .close {
        color: white;
        position: absolute;
        top: 10px;
        right: 25px;
        font-size: 35px;
        font-weight: bold;
    }

    .close:hover,
    .close:focus {
        color: #999;
        text-decoration: none;
        cursor: pointer;
    }
    .cursor {
        cursor: pointer;
    }

    .demo {
        opacity: 0.6;
    }

    .active,
    .demo:hover {
        opacity: 1;
    }
    .hover-shadow:hover {
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    }
</style>

<br>
<br>
<br>
<div class="container">
<!-- Section: Blog v.3 -->
<section class="my-5">

  <!-- Section heading -->
  <h2 class="h1-responsive font-weight-bold text-center my-5">Recent posts</h2>
  <!-- Section description -->
  <p class="text-center dark-grey-text w-responsive mx-auto mb-5">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

  <!-- Grid row -->
  <div class="row">

    <!-- Grid column -->
    <div class="col-lg-5 col-xl-4">

      <!-- Featured image -->
      <div class="view overlay rounded z-depth-1-half mb-lg-0 mb-4">
        <img class="img-fluid"  src="https://mdbootstrap.com/img/Photos/Others/images/49.jpg" onclick="openModal()" class="hover-shadow cursor" alt="Sample image">
        <a>
          <div class="mask rgba-white-slight"></div>
        </a>
      </div>

    </div>
    <!-- Grid column -->

    <!-- Grid column -->
    <div class="col-lg-7 col-xl-8">

      <!-- Post title -->
      <h3 class="font-weight-bold mb-3"><strong>।। আহিবনে �?জাক ধ�?ম�?হা ? ।।</strong></h3>
      <!-- Excerpt -->
      <p class="dark-grey-text">
                কলিয়া ডাৱৰৰ চাদৰখন মেৰ�?ৱাই
কাৰ অপেক�?ষাত আজি সৌ আকাশখন ?
<br>
চিকমিক বিজ�?লী, ৰিম�?িম বৰষ�?ণ

লগতে আকৌ মেঘৰ গৰ�?জন

কাৰ বাবে বাৰ�? �?ই মহাআয়োজন ?
<br>
ধ�?ম�?হা নামিব কিজানি...

স�?বৰ�?গৰ কোনো দিব�?যাংগনা হৈ
<br>
ধীৰ-স�?থিৰ ধৰিত�?ৰীৰ ধ�?যান ভংগ কৰিবলৈ !
<br>
শান�?ত সম�?দ�?ৰক অশান�?ত কৰি ত�?লিবলৈ !!

�?ৰা... কিমান শ�?নিবা আৰ�?
<br>
মাতাল মেঘৰ তৰ�?জন-গৰ�?জন ?
<br>
কিমান চাবা আৰ�? ধ�?ম�?হাৰ তাণ�?ডৱলীলাৰ

সেই �?কেই নাটখন ?
<br>
আহিবনে �?জাক ধ�?ম�?হা

যিয়ে আনিব �?ক পৰিবৰ�?তনৰ প�?লাৱন... ??
<br>
মায়াবিনী হৈ ধৰা নিদি

মিছা মোহ মায়া ভংগ কৰিবলৈ

গছ-বিৰিখৰ ডাল-পাত সৰাবলৈ নহয়,
<br>
দ�?ৰ�?নীতি, ক�?সংস�?কাৰ, অন�?ধবিশ�?বাসৰ দৰে
<br>
অপতৃণবোৰ উঘালিবলৈ...
<br>
বিশ�?বাসৰ বীজ �?টি অংক�?ৰিত হোৱাকে
<br>
সত�?যৰ মাটিডৰাক জীপাল কৰিবলৈ...
<br>
আহিবনে �?জাক ধ�?ম�?হা...?
<br>
গাও�?, চহৰ, নগৰ
<br>
বানপানীৰে ব�?ৰাবলৈ নহয়,
<br>
হত�?যা-হিংসাৰে উত�?তপ�?ত, য�?দ�?ধৰে জৰ�?জৰিত
<br>
পৃথিৱীৰ ব�?ক�?লৈ শিতল জলধাৰা বোৱাবলৈ...
<br>
দ�?:খিয়াৰ প�?জা উৰ�?ৱাবলৈ নহয়,
<br>
অহংকাৰৰ স�?উচ�?চ অট�?টালিকা বগৰাবলৈ...
<br>
ভেদাভেদ পাহৰি নি:স�?বাৰ�?থ প�?ৰেমৰ
<br>
উজ�?জ�?বল ৰামধেন�?খন সজাবলৈ...
<br>
আহিবনে �?জাক ধ�?ম�?হা...?
<br>
আহিব কিজানি...
<br>
�?জাক ধ�?ম�?হা আহিব কিজানি...!!!</p>
      <!-- Post data -->
      <p>by <a class="font-weight-bold">Jessica Clark</a>, 19/04/2018</p>
      <!-- Read more button -->
      <a class="btn btn-primary btn-md">Read more</a>

    </div>
    <!-- Grid column -->

  </div>
  <!-- Grid row -->

  <hr class="my-5">

  <!-- Grid row -->
  <div class="row">

    <!-- Grid column -->
    <div class="col-lg-5 col-xl-4">

      <!-- Featured image -->
      <div class="view overlay rounded z-depth-1-half mb-lg-0 mb-4">
        <img class="img-fluid" src="https://mdbootstrap.com/img/Photos/Others/images/31.jpg" alt="Sample image">
        <a>
          <div class="mask rgba-white-slight"></div>
        </a>
      </div>

    </div>
    <!-- Grid column -->

    <!-- Grid column -->
    <div class="col-lg-7 col-xl-8">

      <!-- Post title -->
      <h3 class="font-weight-bold mb-3"><strong>Title of the news</strong></h3>
      <!-- Excerpt -->
      <p class="dark-grey-text">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident et accusamus iusto odio dignissimos et dolorum fuga.</p>
      <!-- Post data -->
      <p>by <a class="font-weight-bold">Jessica Clark</a>, 16/04/2018</p>
      <!-- Read more button -->
      <a class="btn btn-primary btn-md">Read more</a>

    </div>
    <!-- Grid column -->

  </div>
  <!-- Grid row -->

  <hr class="my-5">

  <!-- Grid row -->
  <div class="row">

    <!-- Grid column -->
    <div class="col-lg-5 col-xl-4">

      <!-- Featured image -->
      <div class="view overlay rounded z-depth-1-half mb-lg-0 mb-4">
        <img class="img-fluid" src="https://mdbootstrap.com/img/Photos/Others/images/52.jpg" alt="Sample image">
        <a>
          <div class="mask rgba-white-slight"></div>
        </a>
      </div>

    </div>
    <!-- Grid column -->

    <!-- Grid column -->
    <div class="col-lg-7 col-xl-8">

      <!-- Post title -->
      <h3 class="font-weight-bold mb-3"><strong>Title of the news</strong></h3>
      <!-- Excerpt -->
      <p class="dark-grey-text">Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, psam voluptatem quia consectetur.</p>
      <!-- Post data -->
      <p>by <a class="font-weight-bold">Jessica Clark</a>, 12/04/2018</p>
      <!-- Read more button -->
      <a class="btn btn-primary btn-md">Read more</a>

    </div>
    <!-- Grid column -->

  </div>
  <!-- Grid row -->

</section>
<!-- Section: Blog v.3 -->

</div>


<div class="container">
    <div class="row"style="background-color:  #ffccff" >
        <div class="col-md-5">
            <img src="college_week/DSC02038.JPG" style="width:100%;height:100%;padding: 25px 25px 25px 15px" onclick="openModal()"  class="hover-shadow cursor"></div>
        <div class="col-md-7" style="width:100%;height:100%;padding: 25px 25px 25px 15px">
            <h2 class="font-weight-normal text-dark"><center>।। আহিবনে �?জাক ধ�?ম�?হা ? ।।</center></h2>
            <h5 class="font-weight-normal text-dark">

                কলিয়া ডাৱৰৰ চাদৰখন মেৰ�?ৱাই
কাৰ অপেক�?ষাত আজি সৌ আকাশখন ?
<br>
চিকমিক বিজ�?লী, ৰিম�?িম বৰষ�?ণ

লগতে আকৌ মেঘৰ গৰ�?জন

কাৰ বাবে বাৰ�? �?ই মহাআয়োজন ?
<br>
ধ�?ম�?হা নামিব কিজানি...

স�?বৰ�?গৰ কোনো দিব�?যাংগনা হৈ
<br>
ধীৰ-স�?থিৰ ধৰিত�?ৰীৰ ধ�?যান ভংগ কৰিবলৈ !
<br>
শান�?ত সম�?দ�?ৰক অশান�?ত কৰি ত�?লিবলৈ !!

�?ৰা... কিমান শ�?নিবা আৰ�?
<br>
মাতাল মেঘৰ তৰ�?জন-গৰ�?জন ?
<br>
কিমান চাবা আৰ�? ধ�?ম�?হাৰ তাণ�?ডৱলীলাৰ

সেই �?কেই নাটখন ?
<br>
আহিবনে �?জাক ধ�?ম�?হা

যিয়ে আনিব �?ক পৰিবৰ�?তনৰ প�?লাৱন... ??
<br>
মায়াবিনী হৈ ধৰা নিদি

মিছা মোহ মায়া ভংগ কৰিবলৈ

গছ-বিৰিখৰ ডাল-পাত সৰাবলৈ নহয়,
<br>
দ�?ৰ�?নীতি, ক�?সংস�?কাৰ, অন�?ধবিশ�?বাসৰ দৰে
<br>
অপতৃণবোৰ উঘালিবলৈ...
<br>
বিশ�?বাসৰ বীজ �?টি অংক�?ৰিত হোৱাকে
<br>
সত�?যৰ মাটিডৰাক জীপাল কৰিবলৈ...
<br>
আহিবনে �?জাক ধ�?ম�?হা...?
<br>
গাও�?, চহৰ, নগৰ
<br>
বানপানীৰে ব�?ৰাবলৈ নহয়,
<br>
হত�?যা-হিংসাৰে উত�?তপ�?ত, য�?দ�?ধৰে জৰ�?জৰিত
<br>
পৃথিৱীৰ ব�?ক�?লৈ শিতল জলধাৰা বোৱাবলৈ...
<br>
দ�?:খিয়াৰ প�?জা উৰ�?ৱাবলৈ নহয়,
<br>
অহংকাৰৰ স�?উচ�?চ অট�?টালিকা বগৰাবলৈ...
<br>
ভেদাভেদ পাহৰি নি:স�?বাৰ�?থ প�?ৰেমৰ
<br>
উজ�?জ�?বল ৰামধেন�?খন সজাবলৈ...
<br>
আহিবনে �?জাক ধ�?ম�?হা...?
<br>
আহিব কিজানি...
<br>
�?জাক ধ�?ম�?হা আহিব কিজানি...!!!

            </h5>
        </div>
    </div>
    <br>
    <br>
   <div class="row" style="background-color: lightblue">
        <div class="col-md-5">
            <img src="college_week/DSC02038.JPG" style="width:100%;height:100%;padding: 25px 25px 25px 15px" onclick="openModal()"  class="hover-shadow cursor"></div>
        <div class="col-md-7" style="width:100%;height:100%;padding: 25px 25px 25px 15px">
            <h2 class="font-weight-normal text-dark"><center>শেষৰাতিৰচিঠি.....</center></h2>
            <h5 class="font-weight-normal text-dark">


প�?ৰেয়সী....পৰিচয় নজনাকৈ ত�?মি জানো মোক প�?ৰেম কৰিবা...!!!!

হয়..সিদিনা ত�?মি �?কাপ চাহ খাব কোৱা হলে
হয়তো আজি মোৰ কাগজ আৰ�? নীলা চিয়া�?হীৰ অপব�?যয় নহলহে�?তেন...!

.মোৰ দেউতা �?জন শৱ প�?ৰা মান�?হ...!
�?টা উৎকট গোন�?ধ কলিজাত বান�?ধি 
চটফটাই ফ�?ৰে মোৰ দেউতা....
জ�?বলাই নিতৌ �?ক�?ৰা বিচ�?ছিন�?ন কামনাৰ অগ�?নি..!!
হয়..মোৰ মাৰ জিকমিক শাৰীৰ ভিতৰত 
জ�?বলি থাকে �?টা উলংগ দেহা...আৰ�?
সপোনৰ আঙ�?ঠা বোৰে ছাই হৈ
কলা সানে মোৰ জোনাক ৰাতিত...!

প�?ৰেয়সী..
          তোমাৰ দামী লিপষ�?টিকৰ ৰঙটো মোক কবলৈ নাপাহৰিবা...
পিছে মোৰ ৱালেটৰ ওজন খ�?ব কম...
হয়তো নোৱাৰিব ধৰি ৰাখিব তোমাৰ সৌন�?দৰ�?য�?যক...!!
  
জানা 
       কেকটাছ ভাল লাগে মোৰ..!
মোক শিকায় যন�?ত�?ৰনাত জীয়াই থাকিবলৈ....

আকাশৰ সৰ�? তৰাৰ প�?ৰেমিক মই...!
অনন�?ত সি অমানিশাৰ অন�?ধকাৰত 
জোনাকৰ দৰে পলাই ন�?ফ�?ৰে....

হব আৰ�? নিলিখো�?...!
মোক ব�?জিবলৈ �?খনি বগা কাগজ দিলো�? তোমাক....
আখৰবোৰ চিনি নাপালে কবা
জানাই নহয়...গা�?ওৰ লৰা মূৰ�?খ লৰা...!!!

            </h5>
        </div>
    </div>

<div id="myModal" class="modal">
    <span class="close cursor" onclick="closeModal()">&times;</span>
    <div class="modal-content">

        <div class="mySlides">

            <img src="college_week/DSC02038.JPG"style="width:100%;max-height:500px;" >
        </div>

        <div class="mySlides">

            <img src="img_snow_wide.jpg" style="width:100%;max-height:500px;">
        </div>

        <div class="mySlides">

            <img src="img_mountains_wide.jpg" style="width:100%;max-height:500px;">
        </div>

        <div class="mySlides">

            <img src="img_lights_wide.jpg" style="width:100%;max-height:500px;">
        </div>

    </div>
</div>
</div>
<br>
<br>
<br>

<script>
    function openModal() {
        document.getElementById('myModal').style.display = "block";
    }

    function closeModal() {
        document.getElementById('myModal').style.display = "none";
    }

    var slideIndex = 1;
    showSlides(slideIndex);

    function plusSlides(n) {
        showSlides(slideIndex += n);
    }

    function currentSlide(n) {
        showSlides(slideIndex = n);
    }

    function showSlides(n) {
        var i;
        var slides = document.getElementsByClassName("mySlides");
        var dots = document.getElementsByClassName("demo");
        var captionText = document.getElementById("caption");
        if (n > slides.length) {
            slideIndex = 1
        }
        if (n < 1) {
            slideIndex = slides.length
        }
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active", "");
        }
        slides[slideIndex - 1].style.display = "block";
        dots[slideIndex - 1].className += " active";
        captionText.innerHTML = dots[slideIndex - 1].alt;
    }
</script>


<?php include 'footer.php'; ?>