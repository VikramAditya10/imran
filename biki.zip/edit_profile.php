<?php include 'header.php'; ?>
<?php include 'header_navbar.php'; ?>
<div class="container">
<br><br><br>
  <form method="POST">
  <div class="form-group">
    <label for="usignupuname">User name:</label>
    <input type="text" class="form-control"  id="usignupuname">
  </div>
  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" id="usignupemail">
  </div>
  <div class="form-group">
    <label for="usignuppwd">Password:</label>
    <input type="password" class="form-control" id="usignuppwd">
  </div>
  <div class="form-group">
    <label for="confrmpwd">Confirm Password:</label>
    <input type="password" class="form-control" id="usignupconfrmpwd">
  </div>
  <div class="row"> 
  <div class="col-md-offset-4 col-xs-offset-1 text-center upload-btn-wrapper " style="left-padding:10%;">
  <button class="btn upload-btn">Upload a file</button>
  <input type="file" id="imgInp" name="imageFile"/>
</div></div>
<br><br>
  <div class="text-center row">
<div class="col-md-offset-2 col-md-5">
<!-- <div id="imgPre" class="image-preview" style="background-image:url('images/placeholder/uploadarrow.png'); "></div> -->
<img id="imgPre" src="images/placeholder/uploadarrow.png"  alt="..." class="img-preview img-thumbnail">
</div>
  </div>
  <div id="signupError"></div>
  <br>
  <div class="row">
  <div class="col-xs-offset-5 col-md-offset-4 col-xs-2 col-md-2">
  <button type="submit" id="btnSignup" class="btn btn-primary ">Save</button>
</div>
  </form></div>
  
<script>

</script>

