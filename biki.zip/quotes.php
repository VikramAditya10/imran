<style></style>
<div class="container" style="background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.6)), url('images/placeholder/quotes.jpg');background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;">
    
    <div class="row">
        <div class="col-lg-12">
            <div  style="font-family: Arial, Helvetica, sans-serif;color:white">
                <h3 style=""><center><b>Quote Of The Day</b></center></h3>
<blockquote><h3>Whenever you see a successful business, someone once made a courageous decision. </h3></blockquote>
                <h5 style=""><center>~Peter F. Drucker</center></h5>

 </div> 
        </div>
    </div>
    
</div>