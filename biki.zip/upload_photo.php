<?php 
session_start();
	if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) : ?>
<?php include("image_upload.php");?>
<?php include 'header.php'; ?>
<?php include 'header_navbar.php'; ?>
<?php
include("db.php");


$db=new DB();
$result=$db->execute_query("select name from events");
?>

<div class="container">
 <div class="panel panel-primary" style="margin-top:17%;">
      <div class="panel-heading" style="text-align:center;"><b>Upload Photo</b></div>
      <div class="panel-body">
<form  method="POST" action=<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> enctype="multipart/form-data">
<div class="row">
<div class="col-md-offset-4 col-md-6 col-xs-12">
  <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label upload-form-ele " >
  
    <input class="mdl-textfield__input" name="caption" type="text" id="textCaption" required>
    <label class="mdl-textfield__label" for="textCaption">Caption</label>
  </div>
  </div></div>
   <div class="row"> <div class="col-md-offset-4 col-md-6 col-xs-12">
  <div class=" mdl-textfield mdl-js-textfield mdl-textfield--floating-label upload-form-ele ">
    <input class="form-group mdl-textfield__input" name="tag" type="text" id="textTag" required>
    <label class="mdl-textfield__label" for="textTag">Tag</label>

  </div>
  </div></div>
    <br>
	
 <div class="row"> <div class="col-md-offset-4 col-md-6 col-xs-12">
   <div class="flex-md-column justify-content-md-center mdl-textfield mdl-js-textfield mdl-textfield--floating-label upload-form-ele">
    <input class="form-group mdl-textfield__input" name="event" type="text" id="textTag" required>
    <label class="mdl-textfield__label" for="textTag">Event</label>

  </div></div></div>

  
    <br>
	<div class="row"> <div class="col-md-offset-4 col-md-6 col-xs-12">
  <div class="text-center upload-btn-wrapper " style="left-padding:10%;">
  <button class="btn upload-btn">Upload a file</button>
  <input type="file" id="imgInp" name="imageFile"/>
</div></div></div>
<br><br>
  <div class="row">
<div class="col-md-offset-3 col-md-6 col-xs-12">
<img id="imgPre" src="images/placeholder/uploadarrow.png"  alt="..." class="img-thumbnail">
</div>
  </div>
<br><br>
  <div class="row"> 
<div class="col-md-offset-5 col-xs-offset-4 col-md-2 col-xs-2">
      <button type="submit" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent">Submit</button>
    </div>
  </div>
</form>
</div>
</div></div>
    
<?php
if (!empty($_POST)){
	$status=1;
$caption=$_POST["caption"];
$tags=$_POST["tag"];
$event=$_POST["event"];
$year=2018;//$_POST["year"];
$username=$_SESSION["email"];
$img_upload= new ImageUpload($_FILES,"imageFile");
$folder=$img_upload->makeUploadDir($event,$year,$username);
$image=$img_upload->uploadImage($folder);
$sql="insert into images(image,event,year,uploaded_by,tags,status,caption,upload_date)values('".$image."','".$event."','".$year."','".$username."','".$tags."','".$status."','".$caption."',"."NOW())";
$db->execute_query($sql);
$uploadStatus="Sucessfully uploaded.";
}

?>
<?php if (!empty($_POST)): ?>
<div class="alert alert-success alert-dismissible">
  <button type="button" class="close" data-dismiss="alert">&times;</button>
  <strong>Status: </strong> <?php echo $uploadStatus;?>
</div>
	<?php endif?>
</body>
<?php include 'footer.php';?>
</html>
<?php endif?>
