<?php 
session_start();
	if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) : ?>
<?php include("image_upload.php");?>


<?php
include("db.php");


$db=new DB();
$result=$db->execute_query("select * from user where email='".$_SESSION['email']."'");
$row=$db->fetch_result($result);
$name=$row['name'];
$image=$row['image'];
?>
<?php include 'header.php'; ?>

<?php include 'header_navbar.php'; ?>

	
	<!------------------Medifest Start ------------------------->
<br>

    
  
 



<!------------------Medifest start End----------------------->
<div class="container">
<div  style="background-image: linear-gradient(to top, #9795f0 0%, #fbc8d4 100%);text-align: center;margin-top:45px;">
<div class="" style="">
      <div class="card-body"><h3>Your uploads</h3></div>
</div>
	  <div class="">
<img src="<?php echo $image?>" class="rounded-circle" alt="Cinque Terre">

</div><div class="">
<
<span style="color:black" ><h5><b><?php echo $name?></b></h5></span>
<</div>
</div>
<hr class="hr-danger">
    <div class="row">
        <div class="row">
           <?php
$result=$db->execute_query("select * from images where uploaded_by='".$_SESSION['email']."'");
if($db->num_rows($result)==0)
{
echo	'<h2>You have no image</h2>';
}
else
while($row=$db->fetch_result($result))
{
if (file_exists($row['image'])) 
	echo '<div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="'.$row['caption'].'"
                   data-image="'.$row['image'].'"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="'.$row['image'].'"
                         alt="Another alt text">
                </a>
</div>';
}?>
           

        
          
        </div>

        <div class="modal fade" id="image-gallery" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="image-gallery-title"></h4>
                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">X</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <img id="image-gallery-image" class="img-responsive col-md-12" src="">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary float-left" id="show-previous-image"><i class="fa fa-arrow-left"></i>
                        </button>

                        <button type="button" id="show-next-image" class="btn btn-secondary float-right"><i class="fa fa-arrow-right"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif?>
<?php include 'footer.php'?>