<?php
class ImageUpload{
	var $fileArr;
var $fileName;
var $event;
var $year;
var $username;
/***********************************************************/
public function __construct($fileArr,$fileName){
	$this->fileArr=$fileArr;
	$this->fileName=$fileName;
	
}
/***********************************************************/
public function validateImage(){
  $check = getimagesize($this->fileArr[$this->fileName]["tmp_name"]);
    if($check !== false) 
				$uploadOk = true;
    
	$allowed =  array('gif','png' ,'jpg');
$filename = $this->fileArr[$this->fileName]['name'];
$ext = pathinfo($filename, PATHINFO_EXTENSION);

if(!in_array($ext,$allowed) ) 
				$uploadOk=false;


if ($this->fileArr[$this->fileName]["size"] <64000000)
				$uploadOk = true;

return $uploadOk;
}

/***********************************************************/
public function makeUploadDir(...$params){
$folder = "./uploads/images";
foreach($params as $param) {
$folder=$folder."/".$param;
if(!is_dir($folder)) mkdir($folder);
}
$folder=$folder."/";
return $folder;
}

/************************************************************/
public function uploadImage($folder){
	if($this->validateImage()){
	$targetfileName=$folder.time().$this->fileArr[$this->fileName]['name'];
move_uploaded_file($this->fileArr[$this->fileName]['tmp_name'],$targetfileName);	
return $targetfileName;
	}
	else
		return false;
}
/************************************************************/


}
?>