<?php include 'header.php'; ?>
<?php include 'header_navbar.php'; ?>

<style>
    body {
        font-family: Verdana, sans-serif;
        margin: 0;
    }

    * {
        box-sizing: border-box;
    }

    .row > .column {
        padding: 0 8px;
    }

    .row:after {
        content: "";
        display: table;
        clear: both;
    }

    .column {
        float: left;
        width: 25%;
    }


    /* The Modal (background) */
    .modal {
        display: none;
        position: fixed;
        z-index: 1;
        padding-top: 100px;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: black;
    }

    /* Modal Content */
    .modal-content {
        position: relative;
        background-color: #fefefe;
        margin: auto;
        padding: 0;
        width: 90%;
        max-height:500px;
        max-width: 1500px;
    }

    /* The Close Button */
    .close {
        color: white;
        position: absolute;
        top: 10px;
        right: 25px;
        font-size: 35px;
        font-weight: bold;
    }

    .close:hover,
    .close:focus {
        color: #999;
        text-decoration: none;
        cursor: pointer;
    }
    .cursor {
        cursor: pointer;
    }

    .demo {
        opacity: 0.6;
    }

    .active,
    .demo:hover {
        opacity: 1;
    }
    .hover-shadow:hover {
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    }
</style>

<br>
<br>
<br>

<div class="container">
    <div class="row" style="background-color: lightblue">
        <div class="col-md-5">
            <img src="college_week/DSC02038.JPG" style="width:100%;height:100%;padding: 25px 25px 25px 15px" onclick="openModal()"  class="hover-shadow cursor"></div>
        <div class="col-md-7" style="width:100%;height:100%;padding: 25px 25px 25px 15px">
            <h2 class="font-weight-normal text-dark"><center>The Warriors Of Medicine</center></h2>
            <h5 class="font-italic text-dark">

                "Wherever the art of Medicine is loved, there is also a love of humanity"
                Of the thousands of aspirants who take the medical entrance exams every year, only a few end up realising their dream of studying in a medical college. Ours is a batch of 156 brilliant minds, hailing from different parts of the country. Together, we formed the 55th batch of the northeast's premier institute Gauhati Medical College and Hospital , which came to be known as the Troezianz, meaning the warriors of medicine. The batch-name was given by Rupankar Nandi and the logo was designed by Suraj Pratim Kashyap, both being two of the aspiring medicos of this very batch. We the Troezianz set on our journey of pursuing the noble profession of a physician, on 1st of Sept, 2015. With our weapons of observation, reason, human understanding and dedication, we the Troezianz, are determined to win the battle against disease and serve mankind selflessly to relieve them of their agony.

            </h5>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-8"></div>
    </div>

    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-8"></div>
    </div>

    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-8"></div>
    </div>

    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-8"></div>
    </div>
</div>

<div id="myModal" class="modal">
    <span class="close cursor" onclick="closeModal()">&times;</span>
    <div class="modal-content">

        <div class="mySlides">

            <img src="college_week/DSC02038.JPG"style="width:100%;max-height:500px;" >
        </div>

        <div class="mySlides">

            <img src="img_snow_wide.jpg" style="width:100%;max-height:500px;">
        </div>

        <div class="mySlides">

            <img src="img_mountains_wide.jpg" style="width:100%;max-height:500px;">
        </div>

        <div class="mySlides">

            <img src="img_lights_wide.jpg" style="width:100%;max-height:500px;">
        </div>

    </div>
</div>

<br>
<br>
<br>

<script>
    function openModal() {
        document.getElementById('myModal').style.display = "block";
    }

    function closeModal() {
        document.getElementById('myModal').style.display = "none";
    }

    var slideIndex = 1;
    showSlides(slideIndex);

    function plusSlides(n) {
        showSlides(slideIndex += n);
    }

    function currentSlide(n) {
        showSlides(slideIndex = n);
    }

    function showSlides(n) {
        var i;
        var slides = document.getElementsByClassName("mySlides");
        var dots = document.getElementsByClassName("demo");
        var captionText = document.getElementById("caption");
        if (n > slides.length) {
            slideIndex = 1
        }
        if (n < 1) {
            slideIndex = slides.length
        }
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active", "");
        }
        slides[slideIndex - 1].style.display = "block";
        dots[slideIndex - 1].className += " active";
        captionText.innerHTML = dots[slideIndex - 1].alt;
    }
</script>


<?php include 'footer.php'; ?>