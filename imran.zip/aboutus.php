<?php include 'header.php'; ?>
<?php include 'header_navbar.php'; ?>
<br>
<br>
<br>
        <div class="container">
            <div class="card">
                <div class="card-header deep-orange lighten-1 white-text"><center><b>ABOUT US</b></center></div>
                <div class="card-body">
                    <h4 class="card-title"><h3>About Cincopa</h3>
                        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>


                        HELPING BUSINESSES, MARKETERS AND ONLINE PUBLISHERS SUCCEED WITH THE POWER OF VIDEO AND MEDIA.
                        Founded in 2006, Cincopa is a leading cloud platform for business to host, manage, deliver, distribute and analyze their videos, image and audio on their website and across multiple channels to better engage with their audience to tell their story.
                        We help thousands of customers who require best-in-class performance and analytics, combined with with over 100 customizable video, images and audio players, slideshow and gallery templates, the ability to monetize their online video content across all devices and successfully conduct b2b video marketing.
                        <br>
                        <h3>OUR 5 (CINCO) CORE VALUES:</h3>
                        Design - Our 100+ customizable templates were designed to look good to fit perfectly to any type of web site.
                        Single Platfrom - Provide a single cloud platform for business to host, manage and deliver all types of content needed for their website - Video, Images and Audio
                        Scalable - From a small online marketing web site maintained by a single marketeer to a heavy traffic media-centric web site maintained by a large team
                        Measurable - Provide all the analytics needed to measure the effectiveness of your media for better decision making and revenue maximization.
                        Connectivity - Save you time and money by integrating directly with your favorite CMS, CRM, API tools, Email tools etc. For unique workflow - use our REST API


                </div>
            </div>
        </div>
        <br>
        <br>
        <br>

        <!-----------------Event Body------------------------------>
       <?php include 'footer.php'; ?>