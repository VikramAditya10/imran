<div class="container">
<div class="hero-search">


<div class="row"><div class="col-md-6 col-xs-6 col-lg-6 col-md-offset-3 col-xs-offset-1 col-lg-offset-3" style="margin-top:2%;" ><h1>ASTERIXIS</h1></div></div>

<div class="row" ><div class="col-md-6 col-xs-10 col-lg-6 col-md-offset-3 col-xs-offset-1 col-lg-offset-3" style="margin-bottom:10%;"><form role="form" id="form-buscar">
<div class="form-group" style="margin-bottom:0%;>
<form role="form" id="form-buscar">
<div class="form-group" style="margin-bottom:0%;">
<div class="input-group">
<input id="hero_search" class="form-control" type="search" name="search" placeholder="Search..." required/>
<span class="input-group-btn">
<button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i>
</button>
</span>
</div>
</div>
</form>
</div>
<ul class="search__tags">
  <li  ><a href="#home">suggestion1</a></li>
  <li ><a href="#news">suggestion2</a></li>
  <li ><a href="#contact">suggestion3</a></li>
  <li ><a href="#about">suggestion4</a></li>
    <li ><a href="#about">suggestion5</a></li>
</ul>
<nav class="navbar" >
<ul class="nav navbar-nav navbar-center">
  <li><a href="#"><button type="button" class="btn btn-success" data-toggle="modal" data-target="#userLoginModal1"><span class="glyphicon glyphicon-cloud-upload"></span>Upload</button></a></li>
       <li><a href="#"><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#userLoginModal1"><span class="glyphicon glyphicon-log-in"></span> Login</button></a></li>
    </ul>
</nav>
</div>
</div>

</div>   </div>