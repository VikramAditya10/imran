

<!-- Button to Open the Modal -->
<!--<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#userLoginModal">
  Open modal
</button>-->

<!-- The Modal -->
<div class="modal" id="userLoginModal1">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Sign In/Sign Up to Upload</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
<!-- Nav tabs -->
<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link active" data-toggle="tab" href="#signin">Sign In</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" data-toggle="tab" href="#signup">Sign Up</a>
  </li>
 
</ul>

<!-- Tab panes -->
<div class="tab-content">
  <div class="tab-pane container active" id="signin"><form method="POST">
  <div class="form-group ">
    <label for="usigninemail">Email address:</label>
    <input type="email" class="form-control modal-signin-form" id="usigninemail" name="signinemail">
  </div>
  <div class="form-group">
    <label for="usigninpwd">Password:</label>
    <input type="password" class="form-control modal-signin-form" id="usigninpwd" name="signinpwd">
  </div>
  <div id="siginError"></div>
  <button type="submit" id="usignin" class="btn btn-primary">Sign In</button>
 </form></div>
  <div class="tab-pane container fade" id="signup"><form method="POST">
  <div class="form-group">
    <label for="usignupuname">User name:</label>
    <input type="text" class="form-control modal-signin-form"  id="usignupuname">
  </div>
  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control modal-signin-form" id="usignupemail">
  </div>
  <div class="form-group">
    <label for="usignuppwd">Password:</label>
    <input type="password" class="form-control modal-signin-form" id="usignuppwd">
  </div>
  <div class="form-group">
    <label for="confrmpwd">Confirm Password:</label>
    <input type="password" class="form-control modal-signin-form" id="usignupconfrmpwd">
  </div>
  <div id="signupError"></div>
  <button type="submit" id="btnSignup" class="btn btn-primary">Sign Up</button>
</form></div>
  
</div>
      </div>
     <div class="modal-footer">
      </div>

    </div>
  </div>
</div>
	