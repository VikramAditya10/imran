
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
	  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js'></script>
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
<link rel="stylesheet" href="lib/owlcarousel/owl.carousel.css">
<link rel="stylesheet" href="lib/owlcarousel/owl.theme.default.css">
<script src="lib/owlcarousel/owl.carousel.js"></script>
  <link rel="stylesheet" type="text/css" href="css/user/main.css">
  <style>
  .user-dp {
  display: inline-block;
  width: 50px;
  height: 50px;
border-radius:50%;
  background-repeat: no-repeat;
  background-position: center center;
  background-size: cover;
float: left;
}
.user-dp span{
	margin: 25%;
}

.chip {
    display: inline-block;
    padding: 0 0;
    height: 50px;
    font-size: 16px;
    line-height: 50px;
    border-radius: 25px;
    background-color: #f1f1f1;
}

.chip img {
    float: left;
    margin: 0 10px 0 -25px;
    height: 50px;
    width: 50px;
    border-radius: 50%;
}
  </style>
  </head>
<div class="container">
<div id="profile_icon_carousel" class="owl-carousel owl-theme owl-loaded">
   <div class="owl-stage-outer">
 <div class="owl-stage">
  <div class="owl-item"><div class="chip">
<div class="user-dp" style="background-image: url('./images/banner/home_carousel/2.jpg');"></div>
  John Doe
</div></div>
  <div class="owl-item"><a href=""><div class="user-dp" style="background-image: url('./images/banner/home_carousel/2.jpg');"></div><br><span style="text-align:left;"><h3>Vikram Aditya</h3></span></a> </div>
  <div class="owl-item"><a href=""><div class="user-dp" style="background-image: url('./images/banner/home_carousel/3.jpg');"></div><br><span style="text-align:left;"><h3>Vikram Aditya</h3></span></a></div>
</div>
</div>
</div>
<script>

$(document).ready(function() {
$("#profile_icon_carousel").owlCarousel({
	loop:true,
    margin:10,
    nav:true,
	
	dots:false,
            nav: true,
           autoplay:true,
		   loop:true,
		   autoplayHoverPause:true,
		   autoplayTimeout:2000,
		   responsive:{
        0:{
            items:1,
            nav:true
        },
        600:{
            items:2,
            nav:true
        },
        1000:{
            items:5,
            nav:true,
            loop:false
        }
    }
	});
});
	
</script>