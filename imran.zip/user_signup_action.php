<?php 
include("db.php");
session_start();
$db=new DB();
$uname=$_POST["uname"];
$email=$_POST["email"];
$pwd=$_POST["pswd"];
$sql="insert into user (name, email, pswd, image) values('".$uname."','".$email."',PASSWORD('".$pwd."'),DEFAULT)";

if(!$db->execute_query($sql)){
		$error=array('error'=>$sql);
	}
	else
		
	{
		$error=array('error'=>'user_home.php');
	}
	$_SESSION['loggedin']=true;
	$_SESSION['username']=$email;
	$db->close();
echo $error;
	?>