
<div class="container">
<div id="home_carousel" class="owl-carousel owl-theme owl-loaded">
   <div class="owl-stage-outer">
 <div class="owl-stage">
  <div class="owl-item"> <img class="img-responsive" src="./images/banner/home_carousel/1.jpg" alt="Chania"></div>
  <div class="owl-item"> <img class="img-responsive" src="./images/banner/home_carousel/3.jpg" alt="Chania"> </div>
  <div class="owl-item"> <img class="img-responsive" src="./images/banner/home_carousel/2.jpg" alt="Chania"> </div>
</div>
</div>
</div>
