<?php
session_start();

if(!empty($_SESSION))
	if($_SESSION['loggedin']==true):
?>
<?php include 'header.php'; ?>
<?php include 'loggedin_header_navbar.php'; ?>

<?php include('signup.php');?>
<!---------Carousel Start--------------->
<div class="container">

    <div id="demo" class="carousel slide" data-ride="carousel" >

        <!-- Indicators -->
        <ul class="carousel-indicators">
            <li data-target="#demo" data-slide-to="0" class="active"></li>
            <li data-target="#demo" data-slide-to="1"></li>
            <li data-target="#demo" data-slide-to="2"></li>
        </ul>

        <!-- The slideshow -->
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="img_mountains_wide" alt="Los Angeles" width="1100" height="300">
            </div>
            <div class="carousel-item">
                <img src="img_snow_wide.jpg" alt="Chicago" width="1100" height="300">
            </div>
            <div class="carousel-item">
                <img src="img_nature_wide.jpg" alt="New York" width="1100" height="300">
            </div>
        </div>

        <!-- Left and right controls -->
        <a class="carousel-control-prev" href="#demo" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </a>
        <a class="carousel-control-next" href="#demo" data-slide="next">
            <span class="carousel-control-next-icon"></span>
        </a>
    </div>

</div>
<!---------Carousel End--------------->
<br>

<!---------Shadow Image--------------->



<div class="container" style="background-image:url('https://images.pexels.com/photos/853168/pexels-photo-853168.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260');z-index:-1;">
    
    <div class="row">
        <div class="col-lg-12">
            <div  style="height:200px; background:transparent;z-index:1000">
                <h4 style="font-family:verdana; color:white;"><center><b>Quote Of The Day</b></center></h4>
                <h6 style="font-family:italic; color:white;"><center>Sometimes you can't see yourself clearly until you see yourself through the eyes of others.</center></h6>
                <h6 style="font-family:italic; color:white;"><center>- Ellen DeGeneres</center></h6>

 </div> 
        </div>
    </div>
    
</div>
<!---------Shadow Image End --------------->


 <div class="container">
            <div class="card">
                <h3 class="card-header primary-color white-text"><center>Videos</center></h3>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-12">
                <div class="embed-responsive embed-responsive-16by9">
    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/6E7tQ28DfOw" allowfullscreen></iframe>
</div>
            </div>
   
        </div>
    </div>
</div>
        </div>


<!---------College week start--------------->
<br>


<div class="container">
    <div class="card bg-dark text-white">
        <div class="card-body"><h5>College Week</h5></div>
    </div>
</div>

<!---------------------------------------------------------------------------------->
<div class="container">
<h3 >2018</h3>
<hr style="border-width:2px;"/>
    <div class="row">
        <div class="row">
            <div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/1.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/1.jpg"
                         alt="Another alt text">
                </a>
               
            </div>
            <div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/2.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/2.jpg"
                         alt="Another alt text">
                </a>
            </div>

            <div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/3.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/3.jpg"
                         alt="Another alt text">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/4.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/4.jpg"
                         alt="Another alt text">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/5.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/5.jpg"
                         alt="Another alt text">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/13.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/13.jpg"
                         alt="Another alt text">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/7.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/7.jpg"
                         alt="Another alt text">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/8.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/8.jpg"
                         alt="Another alt text">
                </a>
            </div>

            <div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/9jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/9.jpg"
                         alt="Another alt text">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/10.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/11.jpg"
                         alt="Another alt text">
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/12.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/12.jpg"
                         alt="Another alt text">
                </a>
            </div>
			<div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/14.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/14.jpg"
                         alt="Another alt text">
                </a>
            </div>
			<div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/15.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/15.jpg"
                         alt="Another alt text">
                </a>
            </div>
			<div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/16.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/16.jpg"
                         alt="Another alt text">
                </a>
            </div>
			<div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/17.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/17.jpg"
                         alt="Another alt text">
                </a>
            </div>
			<div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/18.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/18.jpg"
                         alt="Another alt text">
                </a>
            </div>
			<div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/19.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/19.jpg"
                         alt="Another alt text">
                </a>
            </div>
			<div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/20.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/20.jpg"
                         alt="Another alt text">
                </a>
            </div>
<div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/21.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/21.jpg"
                         alt="Another alt text">
                </a>
            </div>
			<div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/22.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/22.jpg"
                         alt="Another alt text">
                </a>
            </div>
			<div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/23.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/23.jpg"
                         alt="Another alt text">
                </a>
            </div>
			<div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/24.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/24.jpg"
                         alt="Another alt text">
                </a>
            </div>
			<div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/25.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/25.jpg"
                         alt="Another alt text">
                </a>
            </div>
			<div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/26.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/26.jpg"
                         alt="Another alt text">
                </a>
            </div>
			<div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/27.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/27.jpg"
                         alt="Another alt text">
                </a>
            </div>
			<div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/28.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/28.jpg"
                         alt="Another alt text">
                </a>
            </div>
			<div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/29.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/29.jpg"
                         alt="Another alt text">
                </a>
            </div>
			<div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/30.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/30.jpg"
                         alt="Another alt text">
                </a>
            </div>
			<div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/31.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/31.jpg"
                         alt="Another alt text">
                </a>
            </div>
			<div class="col-lg-3 col-md-4 col-xs-6 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/32.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/32.jpg"
                         alt="Another alt text">
                </a>
            </div>
			</div>


        <div class="modal fade" id="image-gallery" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="image-gallery-title"></h4>
                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">X</span><span class="sr-only">Close</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <img id="image-gallery-image" class="img-responsive col-md-12" src="">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary float-left" id="show-previous-image"><i class="fa fa-arrow-left"></i>
                        </button>

                        <button type="button" id="show-next-image" class="btn btn-secondary float-right"><i class="fa fa-arrow-right"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php include 'footer.php'; ?>
<?php endif ?>