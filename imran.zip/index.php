<?php session_start();?>
<?php include 'header.php'; ?>

<?php include 'header_navbar.php'; ?>
<?php include('signup.php');?>
<?php include 'hero_search.php';?>

<div class="container"><hr class="hr-primary"></div>
<!---------Carousel Start--------------->
<?php include("home_carousel.php");?>
<!---------Carousel End--------------->
<div class="container"><hr class="hr-success"></div>

<!---------Shadow Image--------------->

<!----quotes----->
<?php include("quotes.php");?>
<!---------Shadow Image End --------------->

 <div class="container">
            <div class="card">
                <h3 class="card-header primary-color white-text"><center>Videos</center></h3>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-12">
                <div class="embed-responsive embed-responsive-16by9">
    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/6E7tQ28DfOw" allowfullscreen></iframe>
</div>
            </div>
   
        </div>
    </div>
</div>
        </div>


<!---------College week start--------------->
<br>


<div class="container">
    <div class="card bg-dark text-white">
        <div class="card-body"><h5>College Week</h5></div>
    </div>
</div>

<!---------------------------------------------------------------------------------->
<div class="container">
<h3 >2018</h3>
<hr style="border-width:2px;"/>

        <div class="row">
            <div class="col-lg-3 col-md-4 col-xs-12 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/1.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/1.jpg"
                         alt="Another alt text">
                </a>
               
            </div>
            <div class="col-lg-3 col-md-4 col-xs-12 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/2.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/2.jpg"
                         alt="Another alt text">
                </a>
            </div>

            <div class="col-lg-3 col-md-4 col-xs-12 thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/3.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/3.jpg"
                         alt="Another alt text">
                </a>
            </div></div>
			<div class="row">
		<div id="home_college_week" class="owl-carousel owl-theme owl-loaded">
   <div class="owl-stage-outer">
 <div class="owl-stage">
          <?php 
		  for($i=4;$i<=32;$i++){
			  echo '<div class="owl-item"> <div class="thumb">
                <a class="thumbnail" href="#" data-image-id="" data-toggle="modal" data-title="College Week 2k18"
                   data-image="college_week/'.$i.'.jpg"
                   data-target="#image-gallery">
                    <img class="img-thumbnail"
                         src="college_week/'.$i.'.jpg"
                         alt="Another alt text">
                </a>
            </div></div>';
			  
		  }
		  
		  ?></div></div></div>
			</div>


        <div class="modal fade" id="image-gallery" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="image-gallery-title"></h4>
                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">X</span><span class="sr-only">Close</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <img id="image-gallery-image" class="img-responsive col-md-12" src="">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary float-left" id="show-previous-image"><i class="fa fa-arrow-left"></i>
                        </button>

                        <button type="button" id="show-next-image" class="btn btn-secondary float-right"><i class="fa fa-arrow-right"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
 
</div></div>
</body>
<!---------College week end--------------->

<!------------------Medifest start End----------------------->



<?php include 'footer.php'; ?>